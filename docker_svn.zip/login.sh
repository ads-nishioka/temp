#!/bin/sh

docker exec -it svn ash
