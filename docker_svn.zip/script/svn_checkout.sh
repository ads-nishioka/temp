#!/bin/sh

# URL
REPO_URL=https://my.redmine.jp/svn/tfc_tc/digital_archive_development/trunk/digital_archive_system

# UserID
USERNAME=nishioka.michio@ad-sol.co.jp

if [ $# -eq 1 ]; then
    USERNAME=$1
fi

# Checkout
svn co $REPO_URL --username $USERNAME ./svn/
