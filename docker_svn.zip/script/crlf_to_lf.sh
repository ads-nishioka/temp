#!/bin/sh

find ./ -type f | xargs sed -i 's/\r//'
