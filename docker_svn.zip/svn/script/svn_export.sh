#!/bin/sh

# URL
REPO_URL=https://my.redmine.jp/svn/tfc_tc/digital_archive_development/trunk/digital_archive_system

# UserID
USERNAME=nishioka.michio@ad-sol.co.jp

if [ $# -ge 1 ]; then
    USERNAME=$1
fi

# Option
OPT=
if [ $# -ge 2 ]; then
    OPT="-r $2"
fi

echo "URL: $REPO_URL"
echo "USERNAME: $USERNAME"
echo "OPTION: $OPT"
echo ""

# Export
svn export $REPO_URL --username $USERNAME $OPT ./svn/export/
