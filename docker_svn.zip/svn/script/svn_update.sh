#!/bin/sh

# UserID
USERNAME=nishioka.michio@ad-sol.co.jp

if [ $# -eq 1 ]; then
    USERNAME=$1
fi

cd ./svn

# Update
svn update --username $USERNAME
